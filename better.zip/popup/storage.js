// export const APP_Storage = {
//     isSUAI: false
// };