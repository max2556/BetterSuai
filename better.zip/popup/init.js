// import { checkURL } from "./URL_checker"

// (function init(){
//     checkURL();
// })()