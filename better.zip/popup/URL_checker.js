// import { getUrl } from "../background.js";
// import { APP_Storage } from "./storage.js";
// export function checkURL() {
//     APP_Storage.isSUAI = getUrl().includes("pro.guap.ru");
//     console.log(APP_Storage.isSUAI);
//     alert(APP_Storage.isSUAI);
// };